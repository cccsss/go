/**
 * 根据实时统计信息计算每个代理的得分。
 * 详情参考：https://www.gogotunnel.com/guide
 * @param   proxy  对象类型，存储代理实时统计信息
 * @author  gogotunnel@gmail.com
 */
function score(proxy) {
    // 如果代理不可用直接返回0分
    if (!proxy.isAvailable) {
        return 0.0;
    }

    // 计算延迟因素得分
    var delayScore = 0.0;
    
    if (proxy.isCN) {
        // 国内代理延迟<10ms得满分
        if (proxy.avgDelay < 10) {
            delayScore = 10.0;
        } else {
            delayScore = Math.round(100.0/proxy.avgDelay);
        }
    } else {
        // 国外代理延迟<100ms得满分
        if (proxy.avgDelay < 100) {
            delayScore = 10.0;
        } else {
            delayScore = Math.round(1000.0/proxy.avgDelay);
        }
    }

    //当前下载速度得分
    var currentDownloadSpeedScore = 0.0;
    // 当前下载速度为0得满分
    if (proxy.currentDownloadSpeed <= 0){
        currentDownloadSpeedScore = 10.0;
    }

    // 下载带宽得分
    var bandwidthScore = 0.0;
    // 下载带宽>=1000KB || <=0 得满分
    if (proxy.maxDownloadBandwidth >= 1000 * 1024 || proxy.maxDownloadBandwidth <= 0){
        bandwidthScore = 10.0;
    } else {
        bandwidthScore = Math.round(proxy.maxDownloadBandwidth/(100.0 * 1024));
    }

    // 代理类型得分
    var proxyTypeScore = 0.0;
    if (proxy.type == "shadowsocks") {
        proxyTypeScore = 10.0;
    } else if (proxy.type == "sni") {
        proxyTypeScore = 8.0;
    } else if (proxy.type == "gogo") {
        proxyTypeScore = 6.0;
    } else if (proxy.type == "openshift3") {
        proxyTypeScore = 4.0;
    } else if (proxy.type == "heroku") {
        proxyTypeScore = 2.0;
    }

    // 命中次数得分
    var hitCountScore = 0.0;
    if (proxy.hitCount <= 100) {
        hitCountScore = 10.0;
    } else {
        hitCountScore = Math.round(1000.0/proxy.hitCount);
    }

    // 错误次数得分, y = -(1.0/2) * x + 10
    var errorCountScore = 0.0;
    // 累积错误次数<=0得满分
    if (proxy.errorCount < 20) {
        errorCountScore = -(1.0/2) * proxy.errorCount + 10;
    }

    // 累计流量得分
    var trafficScore = 0.0;
    // 累计下载流量<100MB得满分
    if (proxy.totalDownloadBytes < 100 * 1024 * 1024){
        trafficScore = 10.0;
    } else {
        trafficScore = Math.round(1000 * 1024 * 1024/proxy.totalDownloadBytes);
    }

    return delayScore * 0.3 + currentDownloadSpeedScore * 0.1 + bandwidthScore * 0.1 + proxyTypeScore * 0.1 +
           errorCountScore * 0.2 + hitCountScore * 0.1 + trafficScore * 0.1;
}