声明：为保证大部分用户的代理速度, 请不要使用GoGo进行长时间的大流量下载任务，例如长时间观看视频，或是使用GoGo进行数据抓取任务，又或是使用GoGo作为下载服务器，
如果发现，GoGo会记录客户端机器的指纹信息，剥夺该客户端使用GoGo的权利。

1. 快速使用
https://www.gogotunnel.com/getStarted

2. 环境准备
   Java虚拟机8或更高版本。下载地址：http://java.com/

3. 文件说明
 1）start.bat
   Windows系统上的启动脚本。
 2）start.command
   Mac OSX系统上的启动脚本，如果没有执行权限则要手动添加，执行 chmod a+x start.command
 3）start.sh
   Linux/Unix系统上的启动脚本，如果没有执行权限则要手动添加，执行 chmod a+x start.sh
 4）config文件夹
   存放配置文件目录。
 5）lib目录
   存放Java程序代码。

4. 关于SwitchySharp
   SwitchySharp是Chrome浏览器的代理切换插件。
   推荐安装方法：
       下载https://www.gogotunnel.com/assets/SwitchySharp.crx，单击Chrome右上角菜单按钮-工具-扩展程序，将SwitchySharp.crx文件拖放到扩展程序窗口。

5. 使用交流
   Gitter聊天室(https://gitter.im/gogotunnel/gogo)
   邮件地址(gogotunnel@@gmail.com)


